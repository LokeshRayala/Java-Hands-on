package com.demo;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AmazonCart {
	WebDriver driver;
  @Test
  public void cart() {
	  
	  driver.get("https://www.amazon.in");
      driver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys("Mobiles");
      driver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys(Keys.ENTER);
      driver.findElement(By.xpath("//*[contains(text(),'Samsung Galaxy S20 FE 5G (Cloud Mint, 8GB RAM, 128GB Storage)')]")).click();
      Set<String> ids = driver.getWindowHandles();
      Iterator<String> it = ids.iterator();
      String parentId = it.next();
      String childId = it.next();
      driver.switchTo().window(childId);
      driver.findElement(By.id("add-to-cart-button")).click();
  }
  
  @BeforeMethod
	public void beforeMethod() {
		
		System.setProperty("webdriver.chrome.driver", "E:\\Java FSD Phase-5\\All Downloads\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	@AfterMethod
	public void afterMethod() {
		
		driver=null;
		
	}
}
